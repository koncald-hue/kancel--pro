# Local security patch

Private vendored copy of picomatch 2.3.2 (used only by the ESLint toolchain through micromatch) with the same
ReDoS guard as `vendor/picomatch` (4.0.8-pravo.0): repeated extglobs whose branch starts with a bare wildcard
followed by content (for example `+(*a)`) are treated as risky and matched literally.

Advisory: https://github.com/advisories/GHSA-fc5q-39xc-vjpf. No fixed upstream release exists as of 2026-11-17.
Replace with an upstream fixed release when one is published.
